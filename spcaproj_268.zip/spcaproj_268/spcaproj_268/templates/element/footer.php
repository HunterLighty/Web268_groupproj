<footer class="text-center text-lg-start bg-primary text-light">
  <!-- Copyright -->
  <div class="text-center p-4">
    © 2021 Copyright:
    <a>Society for the Prevention of Cruelty to Animals
</a>
  </div>
  <!-- Copyright -->
</footer>